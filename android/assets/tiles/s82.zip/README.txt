PURE TILESET BASIC VERSION 2.5

QUICK DISCLAIMER:

This tileset is not Mr.Z's Pure Tileset Update 2.2 or Pure Tileset Update Extreme, nor is it directly based on them. This is directly based off of Wild Bill's Pure Tileset v2 (Beta 182). I know this confuses a lot of people, so that's why this disclaimer is here.

SETUP:

If you have no intention of editing or adding scripts to your quest, you can just completely ignore the PureTiles directory of this zip file and work with this like any other tileset. The scripts that are already compiled into the quest should still function regardless.

You also may want to look through the images in the Tutorials folder since they provide some helpful tips on using various features of the tileset.

SUBSCREENS:

Delete the active subscreen you have no intention of using if you only intend to ever use one subscreen. It will save you a lot of DMap setup grief since all but a few of the DMaps will use active subscreen #2 by default due to how ZC worked pre-2.50. If you wish to change subscreens later, you can either export the one you want from the original tileset file or use the already exported files sitting in the PureTiles directory.

If you want to go back to a simple subscreen from the 2.11 and earlier days, change the setting under Quest->Misc Data->Master Subscreen Type. As ZQuest should warn you, this will erase all custom subscreens and replace them with the setup you selected.

It's worth noting that none of the Master Subscreen Types have all of the items in them (hence why this tileset is bundled with a custom subscreen), so you will be forced to do editing if you want to insert some of them.

NEW ENEMIES:

This is a list of the new enemies that have been added using scripting along with links to their release areas so that you can view their documentation should you wish to edit their settings.

Armos Knights (6) - http://www.purezc.com/forums/index.php?showtopic=57408
- The only variation of these set up in the tileset is the full 6 knights.

Armos LttP - http://www.purezc.com/forums/index.php?showtopic=57409
- This has replaced the regular ZC armos statues. You can revert this by unchecking "Spawn by Armos Flags" in the enemy editor and rechecking it for the original Armos enemy.

Goriya (LTTP) - http://www.purezc.com/forums/index.php?showtopic=57412
- The two varieties are similar to ALTTP. Green is weak to everything while red is only weak to arrows.

Popo - http://www.purezc.com/forums/index.php?showtopic=57414

OTHER NEW STUFF:

Sideview Ladder ffc script (automatic)
- This is set to automatically run on screens with the SCRIPT1 Combo Type (the actual ladder) and sideview gravity, so you shouldn't need to manually place it. 
- Make sure to use the correct SCRIPT1 type ladder if you use existing combos.
- Note that the script will run regardless of whether sideview gravity is on or not, but it is set to not do anything if it doesn't detect it.

itemBundle Item script
- This lets you bundle up to 8 inventory item pickups into a single pickup.
- Specify the item numbers with D0-D7.
- "Bow 1 (Short) & Arrows 1 (Wooden)" is an item that has been added that uses this. It also gives you 30 arrows by default, but this can be changed in the Pickup tab.
- D0: If D0 is negative, it will display an item pickup message containing the positive version of the number entered. -1 would display string 1, -42 would display string 42.

sign ffc script
- This is pretty much a sign where you press a button to see a string if you are facing up and at it.
- The FFC location is where the sign will be.
- D0 is the message string and D1 is the button. 0 is A, 1 is B, 2 is L and 3 is R
- You should have "Messages Freeze the screen" turned on.
- Unlike the script in the database right now, you don't have to be pixel perfect with placing the sign ffc... but it should be invisible (and not combo 0) if you want to be sloppy since the ffc does snap itself onto the grid.

npcscript ffc script
- This is pretty much a sign you can approach from any direction. That's the only difference between this and the sign script.
- The FFC location is where the npc will be.
- D0 is the message string and D1 is the button. 0 is A, 1 is B, 2 is L, and 3 is R.
- You should have "Messages Freeze the screen" turned on.
- You don't have to be pixel perfect in placement since this also snaps to the grid like the sign script... but it should be invisible (and not combo 0) if you want to be sloppy since the ffc does snap itself onto the grid.

itemMessage Item script
- This is a pickup script that lets you play a message when picking up an item.
- D0 is the message string number.

SCRIPTS SETUP:

If you intend to add or edit scripts...

1.) Extract PureTiles (folder and all) to your ZC directory. 
2.) Grab the latest version of ghost.zh and install the ghost_zh folder to your ZC directory: http://www.purezc.com/forums/index.php?showtopic=44087
3.) If the latest version of ghost.zh does not match the version number of the ghost.zh file bundled with the tileset, you should copy ghost.zh from the new version and transfer over the settings from the ghost.zh in the tileset. You may also want to transfer over the documentation text files.
4.) The quest buffer is already set to point to the PureTiles directory in your ZC directory (specifically Pure_Import.zh), so you just need to press Compile in ZQuest to compile the scripts (you should never have to manually import anything). If you change the name of this directory (multiple quests with the same tileset), you need to update it in the ZQuest script buffer and update all instances of it in Pure_Import.zh.

If you wish to edit or add to the global scripts, look in Pure_Global.zh. Everything else you can either follow the examples of the other files imported from Pure_Import.zh or you can add your own files to that list. Header files (.zh) are identical to .z files in every way and you can even use .z instead of .zh in the import command.

You are free to edit everything that is imported however you wish.

I recommend putting all of your import files (std.zh, strings.zh, and such) in Pure_Import.zh so as to avoid duplicates.

CREDITS:

Pure Tileset Basic 2.5 Credits:

Nintendo for The Legend of Zelda series and various graphics and sfx in the tileset.
EZGBZ 2.5 (Akkabus and Lightwulf) - Bombchu, bomb bags, most of the rings, Nayru's Love, random labels (I'm lazy. =P )
Classic (A lot of people) - Random labels (I'm lazy. =P ), Fire Gleeok, some other enemy tiles, upgraded ladder, a few Misc effects, custom subscreens.
PTUX and PTU 2.2 (Mr.Z) - Long Bow, some overworld decorations.
Radien - The Link tiles.
Tingle - Recoloring some of the Link tiles.
Exate - Pure Subscreen Vine
HelpTheWretched - Compiling sound effects: http://noproblo.dayjo.org/ZeldaSounds/
Saffith - ghost.zh, ffcscript.zh, various Ghost enemies, Popo tiles.
Marcus (Orion) - Armos Knight tiles, Goriya tiles, and death sprites are from his ALTTP Tileset.
New default overworld palette is a mishmash between "OW - Springtime" from the Descendant Tileset, "OW - Late Spring" in the DoR Tileset, and the original Pure overworld with a lot of edits by Nick.
Scootaloo - Winter palette, autumn palette, summer palette, spring palette, and helping out with palettes in general.
ShadowTiger - Relational drawing tiles.
Sideview Ladder script in this topic: http://www.purezc.com/forums/index.php?showtopic=56607
LinktheMaster - Sign/npc script, coming up with the idea of updating the original Pure Tileset and pitching it at me a few times and supporting me throughout the endeavour.
The latest PureZC Group Quest Attempt - They sort of nudged me into finally doing this. It's fitting since one of the earliest PureZC Group Quests nudged Wild Bill into making the first Pure Tileset release faster.
Nick - Putting the tileset together, making filler graphics, making Link into Mr. Fantastic instead of a force user when charging a sword, and a few scripts.

And the PureZC community for helping out and giving support!

Pure Tileset 2 Credits:

Wild Bill -
Designer of the set.

Nick -
New enemy tiles (several of which he screwed up and had to fix), inner water corner tiles, and the palletes "Dead Land" and pink dungeon.

PrinceMSC -
Many of the Mystic Land tiles and palletes.

Fox -
Greyscale overworld pallete.

supertails2001 -
More indicator.

Teilyr -
Blue dungeon and autumn palletes.

BigJoe -
New flat surfaced mountains (for lack of a better term).

Zaggarum -
Zelda holding the Triforce sprite.

And everybody else who helped! 